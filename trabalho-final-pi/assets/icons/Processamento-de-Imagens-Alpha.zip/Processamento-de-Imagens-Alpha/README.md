## Processamento de Imagens - PI

Meus arquivos para a matéria de Processamento de Imagens (PI) da PUC Minas com o professor Alexei Manso Correa Machado.

Meus códigos inteiros ou trechos deles podem ser usados por todos, sem restrições. Tenha em mente que eu **NÃO** me responsabilizo por possíveis acusações de plágio ou cola, sejam elas por parte da PUC-MG ou qualquer outra instituição/pessoa.

O uso dos códigos neste repositório é por conta e risco do usuário.